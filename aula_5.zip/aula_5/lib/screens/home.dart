import 'package:flutter/material.dart';

class MyHome extends StatelessWidget {
  const MyHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      drawer: BottomAppBar(color: Colors.amber),

      appBar: AppBar(
        actions: <Widget>[
          IconButton(onPressed: () {}, icon: Icon(Icons.add_circle, color: Colors.white)),
          IconButton(onPressed: () {}, icon: Icon(Icons.exit_to_app, color: Colors.white)),
          IconButton(onPressed: () {}, icon: Icon(Icons.access_alarm, color: Colors.white,))
        ],

        centerTitle: true,

        title: Text("Aula 5", style: TextStyle(color: Colors.white),),
        
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text("flutter", style: TextStyle(fontSize: 30, color: Colors.blue),),
            ),
            Container(
              width: double.infinity,
              height: 200,
              child: Image.asset("lib/assets/pernalonga.jpg"),  
            ),
            Container(
              width: double.infinity,
              height: 200,
              child: Image.asset("lib/assets/papaleguas.jpg"),
            ),
            Container(
              width: double.infinity,
              height: 200,
              child: Image.asset("lib/assets/patolino.png"),
            ),
          ],
        ),
      ),
    );
  }
}